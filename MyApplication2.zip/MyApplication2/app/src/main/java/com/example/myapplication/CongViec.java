package com.example.myapplication;

public class CongViec {
    private int IdCV;
    private String TenCV;

    public CongViec(int idCV, String tenCV){
        IdCV = idCV;
        TenCV = tenCV;
    }
    public int tenCV() {
        return tenCV();
    }

    public int getIdCV() {
        return IdCV;
    }

    public void setIdCV(int idCV) {
        IdCV = idCV;
    }

    public int getTenCV() {
        return 0;
    }
}
